repo: den47k/rawtogpx
branch: main

## Last sync
date: 2026-10-01T22:17:22Z

### Updated in this project
- Redesigned GPX Rebuilder UI as a clickable prototype (desktop + mobile)

## Screen map
| Screen | Repo files |
|---|---|
| GPX Rebuilder.dc.html (desktop) | src/App.tsx, src/ui/components/*, src/core/parseSplits.ts |
| GPX Rebuilder.dc.html (mobile) | src/App.tsx |
