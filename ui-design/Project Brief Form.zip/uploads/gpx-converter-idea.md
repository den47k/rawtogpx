# Task

I need you to design a desktop-first web app that is going to be used as PWA for rebuilding a GPX file from raw time splits that was made by user during a run. I'm looking for clean and minimalistic UI that will be convenient to use on both desktop and phone. Below i've provided a core idea and main functionality of the app.
# GPX Rebuilder: functionality

**Purpose:** rebuild a timestamped running activity (GPX or TCX) for Strava when GPS failed, from a route, the runner's splits and a start or finish time. Runs entirely on the device: no accounts, no server, files never leave the device. Installable and works offline (map tiles excepted). Desktop first, also used on Android phones.

## Route
- **Upload a GPX or TCX route:** by file picker, by dropping it anywhere, or by sharing it from another app on Android. Shows the route length and point count; explains invalid files.
- **Or generate a running track:**
  - 400 m or 250 m; lap count, with fractional laps allowed. If left blank, the laps match the splits' total distance. Every run finishes on the line.
  - Place it by clicking the map, entering coordinates, using the device location, or fitting it automatically from a GPX that goes round the track (works out the location, direction and size).
  - Set the home-straight direction, or flip it to the other straight.
  - Save tracks by name, then pick, update or delete them. The last-used track is restored next visit.

## Splits
- Free-text input that tolerates messy formatting: units in km, m or miles; times as seconds, m:ss or h:mm:ss.
- **Modes:** cumulative or per-lap, detected automatically with a manual override. Optional uniform lap distance, so laps can be entered as times only.
- **Rests:** standing still while the clock runs (`rest 1:30`).
- **Interval workouts:** `6x400 @1:20 jog 200m 1:00`. Rep and recovery times can be the same for all or listed individually, and given as a time or a pace. Recovery can be a jog, a walk or standing.
- **Interval builder:** a form that writes the workout line for you.
- **Errors** are reported per line, with the line number.

## Time
- Anchor on start or finish time, in the local time zone, defaulting to now. The other end is shown live.

## Options
- **When route and splits differ in length:** stretch the splits to fit the route, or cut the route at the last split. Warns when they differ by more than 2%.
- Sample interval (default 1 s).
- Activity name; defaults to Morning, Afternoon, Evening or Night Run.

## Output
- **GPX or TCX download.** TCX has one lap per split, with rests and recoveries as resting laps.
- Default filename from the local start time.
- **Self-check:** the generated file is read back and each split's time is compared with the input. Anything more than 1 s off is flagged.
- **Summary:** stated vs route distance, total time (including rests), average or moving pace, start and finish times.

## Preview
- **Map** showing the route coloured by split pace (faster or slower than average), with start, finish and rest markers, and per-split details on hover.
- **Split check table:** for each split, rep or rest, your time, the file's time and the difference.

## Remembered between visits
Split mode, start/finish choice, lap distance, options, output format, route source, track size and saved tracks. Uploaded routes and splits are never stored.